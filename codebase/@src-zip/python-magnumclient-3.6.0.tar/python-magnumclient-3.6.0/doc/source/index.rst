===============================================
Welcome to python-magnumclient's documentation!
===============================================

Contents
--------

.. toctree::
   :maxdepth: 2

   readme
   installation
   usage
   contributing

Indices and tables
------------------

* :ref:`genindex`
* :ref:`search`
