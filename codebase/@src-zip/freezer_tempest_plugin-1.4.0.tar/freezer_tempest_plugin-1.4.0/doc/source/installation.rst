============
Installation
============

At the command line::

    $ pip install freezer-tempest-plugin

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv freezer-tempest-plugin
    $ pip install freezer-tempest-plugin
