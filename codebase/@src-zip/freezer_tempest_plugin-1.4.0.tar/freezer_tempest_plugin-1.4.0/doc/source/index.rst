.. freezer-tempest-plugin documentation master file, created by
   sphinx-quickstart on Tue Jul  9 22:26:36 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to freezer-tempest-plugin's documentation!
==================================================

Contents:

.. toctree::
   :maxdepth: 2

   readme
   installation
   usage

For Contributors
================

* If you are a new contributor to freezer-tempest-plugin please refer: :doc:`contributor/contributing`

  .. toctree::
     :hidden:

     contributor/contributing

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

