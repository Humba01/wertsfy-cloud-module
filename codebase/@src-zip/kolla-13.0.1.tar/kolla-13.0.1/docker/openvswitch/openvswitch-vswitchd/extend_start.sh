#!/bin/bash

modprobe openvswitch
