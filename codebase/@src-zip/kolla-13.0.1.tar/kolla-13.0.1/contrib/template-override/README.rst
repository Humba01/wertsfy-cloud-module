contrib/template-override directory
===================================

Template override files stored in this directory will not be gated and serve as an
example of how to extend in-tree container images for specific use cases, for example
source build of infrastructure containers.

Templates stored in this directory should have corresponding documentation in
``doc/template-override`` to describe their use.