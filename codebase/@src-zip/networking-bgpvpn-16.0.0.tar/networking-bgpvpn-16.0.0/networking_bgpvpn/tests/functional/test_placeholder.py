from neutron.tests import base


class PlaceholderTest(base.BaseTestCase):

    def test_noop(self):
        pass
