==============
Administration
==============

This section describes how to use kayobe to simplify post-deployment
administrative tasks.

.. toctree::
   :maxdepth: 2

   general
   seed
   infra-vms
   overcloud
   bare-metal
