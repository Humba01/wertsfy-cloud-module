====================
VNF Package commands
====================

VNF Package commands are CLI interface of VNF Package Management Interface in
`ETSI NFV-SOL 005 <https://www.etsi.org/deliver/etsi_gs/NFV-SOL/001_099/005/02.06.01_60/gs_NFV-SOL005v020601p.pdf>`_.

.. autoprogram-cliff:: openstack.tackerclient.v1
   :command: vnf package *
