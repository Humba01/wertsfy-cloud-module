============================================
 Stein Series (5.2.0 - 6.0.x) Release Notes
============================================

.. release-notes::
   :branch: stable/stein
