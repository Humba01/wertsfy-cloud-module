Virtualenv Installation Support
===============================

Virtual environments are now used by default, see :doc:`/install/index`.
