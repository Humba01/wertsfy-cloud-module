======================
Neutron Tempest Plugin
======================

Tempest plugin for Neutron project.

It contains the tempest plugin for the functional testing of Neutron Project.

* Free software: Apache license
* Documentation: https://docs.openstack.org/neutron/latest/
* Source: https://opendev.org/openstack/neutron-tempest-plugin
* Bugs: https://bugs.launchpad.net/neutron
* Release notes: https://docs.openstack.org/releasenotes/neutron-tempest-plugin/
