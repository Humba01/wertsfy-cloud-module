enable-packages-install

This element will set the install types to package for all elements.
