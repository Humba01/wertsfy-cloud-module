===============
Available Hooks
===============

The available hooks are:


.. toctree::
   :glob:
   :maxdepth: 1

   hooks/*
