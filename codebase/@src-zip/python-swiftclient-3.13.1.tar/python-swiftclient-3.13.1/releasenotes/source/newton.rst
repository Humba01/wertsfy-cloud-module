=============================
 Newton Series Release Notes
=============================

.. release-notes::
   :branch: stable/newton
