CLI Reference
=============

.. toctree::
   :maxdepth: 1

   solum-status
