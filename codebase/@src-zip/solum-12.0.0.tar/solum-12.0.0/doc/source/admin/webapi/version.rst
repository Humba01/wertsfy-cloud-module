=================
Version discovery
=================

.. autotype:: solum.api.controllers.root.Version
   :members:
