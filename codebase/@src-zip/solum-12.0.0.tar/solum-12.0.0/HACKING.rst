========================
Solum Style Commandments
========================

Read the OpenStack Style Commandments https://docs.openstack.org/hacking/latest/

See Also: CONTRIBUTING.rst

Solum Specific Commandments
---------------------------

- [M322] Method's default argument shouldn't be mutable.
