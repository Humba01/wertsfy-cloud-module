Setup
-----
These scripts require installation of OpenStack diskimage-builder
https://opendev.org/openstack/diskimage-builder

The package is available on Ubuntu, Fedora, and Red Hat Enterprise Linux
