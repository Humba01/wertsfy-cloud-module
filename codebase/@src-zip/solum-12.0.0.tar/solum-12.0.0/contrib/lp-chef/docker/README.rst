# docker builder!

build a chef docker image from examples/language-packs/chef
