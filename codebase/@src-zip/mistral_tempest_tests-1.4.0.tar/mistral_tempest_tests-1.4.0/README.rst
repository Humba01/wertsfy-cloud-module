======================
Mistral Tempest plugin
======================

Tempest plugin for Mistral Project.

It contains the tempest plugin for the functional testing of Mistral Project.

* Free software: Apache license
* Documentation: https://docs.openstack.org/mistral/latest
* Release notes: https://docs.openstack.org/releasenotes/mistral/
* Source: https://opendev.org/openstack/mistral-tempest-plugin
* Bugs: https://bugs.launchpad.net/mistral
