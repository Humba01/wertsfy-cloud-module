.. include:: ../../../README.rst
  :start-after: inclusion-start-marker-configuration
  :end-before: inclusion-end-marker-configuration

