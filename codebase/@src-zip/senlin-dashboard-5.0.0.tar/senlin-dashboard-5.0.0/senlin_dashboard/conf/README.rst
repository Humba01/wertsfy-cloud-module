==================
Senlin Policy File
==================

Enable senlin policy::

    $ cp senlin_dashboard/conf/senlin_policy.json openstack-dashboard/openstack_dashboard/conf
