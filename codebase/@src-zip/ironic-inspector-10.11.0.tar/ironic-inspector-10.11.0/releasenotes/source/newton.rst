===========================================
Newton Series (3.3.0 - 4.2.x) Release Notes
===========================================

.. release-notes::
   :branch: origin/stable/newton
