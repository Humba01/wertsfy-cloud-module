==========================================
Stein Series (8.1.0 - 8.2.x) Release Notes
==========================================

.. release-notes::
   :branch: stable/stein
