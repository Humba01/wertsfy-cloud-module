===========================================
Mitaka Series (2.3.0 - 3.2.x) Release Notes
===========================================

.. release-notes::
   :branch: origin/stable/mitaka
