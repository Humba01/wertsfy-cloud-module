.. include:: ../../README.rst

Using Ironic Inspector
======================

.. toctree::
  :maxdepth: 2

  install/index
  cli/index
  configuration/index
  user/index
  admin/index

Contributor Docs
================

.. toctree::
  :maxdepth: 2

  contributor/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
