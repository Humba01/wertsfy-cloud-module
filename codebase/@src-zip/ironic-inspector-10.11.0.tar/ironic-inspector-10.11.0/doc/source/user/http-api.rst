HTTP API
--------

See https://docs.openstack.org/api-ref/baremetal-introspection/
