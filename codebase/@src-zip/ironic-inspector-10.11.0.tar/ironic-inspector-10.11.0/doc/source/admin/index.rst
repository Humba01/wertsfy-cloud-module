Administrator Guide
===================

How to upgrade Ironic Inspector
-------------------------------

.. toctree::
  :maxdepth: 2

  upgrade

Dnsmasq PXE filter driver
-------------------------

.. toctree::
  :maxdepth: 2

  dnsmasq-pxe-filter
