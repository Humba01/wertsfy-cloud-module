.. _contributing_link:

.. include:: ../../../CONTRIBUTING.rst

Python API
~~~~~~~~~~

.. toctree::
  :maxdepth: 1

  api/modules

Ironic Inspector CI
~~~~~~~~~~~~~~~~~~~

It's important to understand the role of each job in the CI. To facilitate
that, we have created the documentation below.

.. toctree::
  :maxdepth: 1

  Job roles in the CI <jobs-description>
