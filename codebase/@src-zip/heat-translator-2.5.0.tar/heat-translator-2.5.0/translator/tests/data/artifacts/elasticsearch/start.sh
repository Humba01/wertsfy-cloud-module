#!/bin/bash
# This script starts elasticsearch as a service in init.d
service elasticsearch stop
service elasticsearch start
