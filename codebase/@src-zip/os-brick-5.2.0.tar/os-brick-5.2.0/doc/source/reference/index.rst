API Documentation
=================

The **os-brick** package provides the ability to collect host initiator
information as well as discovery volumes and removal of volumes from a host.

.. toctree::
   :maxdepth: 2

   os_brick/index
