User Guide

.. toctree::
   :maxdepth: 2

   shell
