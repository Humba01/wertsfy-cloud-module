To generate the sample policy.yaml file, run the following command from the top
level of the cyborg directory:

    tox -egenpolicy
