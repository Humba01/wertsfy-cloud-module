==================================================
Configuration options for the Acceleration service
==================================================

The following options can be set in the ``/etc/cyborg/cyborg.conf`` config file
A :doc:`sample configuration file <sample-config>` is also available.

.. show-options::
   :config-file: tools/config/cyborg-config-generator.conf
