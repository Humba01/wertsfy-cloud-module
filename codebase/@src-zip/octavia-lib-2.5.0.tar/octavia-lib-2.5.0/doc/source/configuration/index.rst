=============
Configuration
=============

The octavia-lib library does not currently use any `oslo configuration <https://docs.openstack.org/oslo.config/latest/>`_ settings.
