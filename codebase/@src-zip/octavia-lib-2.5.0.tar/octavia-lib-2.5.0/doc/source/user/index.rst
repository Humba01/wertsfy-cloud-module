===========
Users guide
===========

The octavia-lib is a library supporting Octavia provider drivers.

Instructions for using the library are provided in the `Provider Driver Development Guide <https://docs.openstack.org/octavia/latest/contributor/guides/providers.html>`_.
