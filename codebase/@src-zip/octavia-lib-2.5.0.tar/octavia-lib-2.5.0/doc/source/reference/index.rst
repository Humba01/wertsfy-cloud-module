==========
References
==========

.. toctree::
   :glob:
   :maxdepth: 1

   Octavia Introduction <https://docs.openstack.org/octavia/latest/reference/introduction.html>
   Octavia Glossary <https://docs.openstack.org/octavia/latest/reference/glossary.html>
   Octavia Project Documentation <https://docs.openstack.org/octavia/latest/>
   Octavia API Reference <https://docs.openstack.org/api-ref/load-balancer/>

.. only: html

   Indices and Search
   ------------------

   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`

.. only:: latex

   Module Reference
   ----------------

   .. toctree::
      :hidden:

      modules/modules
