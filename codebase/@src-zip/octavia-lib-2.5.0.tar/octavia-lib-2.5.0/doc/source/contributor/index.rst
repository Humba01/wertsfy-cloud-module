=========================
Contributor Documentation
=========================

Contributor Guidelines
----------------------
.. toctree::
   :glob:
   :maxdepth: 1

   Octavia Constitution <https://docs.openstack.org/octavia/latest/contributor/CONSTITUTION.html>
   Octavia Style Commandments <https://docs.openstack.org/octavia/latest/contributor/HACKING.html>

.. include:: ../../../CONTRIBUTING.rst
