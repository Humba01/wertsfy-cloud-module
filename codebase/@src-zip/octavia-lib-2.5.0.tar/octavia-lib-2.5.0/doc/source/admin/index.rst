====================
Administrators guide
====================

The octavia-lib is a library supporting Octavia provider drivers.

There are no administrator tasks or settings for octavia-lib.

Information on administrating Octavia deployments is available in the
`Octavia Administration Guide <https://docs.openstack.org/octavia/latest/admin/index.html>`_.
