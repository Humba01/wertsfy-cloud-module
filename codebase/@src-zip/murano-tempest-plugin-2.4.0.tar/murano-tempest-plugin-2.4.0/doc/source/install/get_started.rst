=======================
murano service overview
=======================
The murano service provides...

The murano service consists of the following components:

``murano_tempest_tests-api`` service
  Accepts and responds to end user compute API calls...
