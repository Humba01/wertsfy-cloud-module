API Documents
=============

Freezer has different types of documents as follow:

.. toctree::

    jobs.rst
    actions.rst
    sessions.rst
