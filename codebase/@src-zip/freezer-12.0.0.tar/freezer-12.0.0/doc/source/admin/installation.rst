Installation
============


Agent & Scheduler Installation:
-------------------------------

.. toctree::
   :maxdepth: 2

   agent-scheduler-install

Freezer API Installation
------------------------

.. toctree::
   :maxdepth: 2

   freezer-api-install

Web UI Installation
-------------------

.. toctree::
   :maxdepth: 2

   freezer-web-ui-install

Backup as a Service Platform Installation
-----------------------------------------

.. toctree::
   :maxdepth: 2

   complete-install
