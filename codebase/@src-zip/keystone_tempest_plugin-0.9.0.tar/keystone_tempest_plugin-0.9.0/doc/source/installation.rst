============
Installation
============

At the command line::

    $ pip install openstack

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv openstack
    $ pip install openstack
