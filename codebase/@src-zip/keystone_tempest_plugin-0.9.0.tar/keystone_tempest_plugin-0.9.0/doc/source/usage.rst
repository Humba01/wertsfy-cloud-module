========
Usage
========

To use openstack in a project::

    import keystone_tempest_plugin
