=============
Presentations
=============

- `Tap-As-A-Service What You Need to Know Now
  <https://www.openstack.org/videos/video/tap-as-a-service-what-you-need-to-know-now>`_

    40 min presentation at OpenStack Summit Austin, April 2016,
    including a demo with Horizon.

- `Using Open Source Security Architecture to Defend against Targeted Attacks`
  <https://www.openstack.org/videos/video/using-open-source-security-architecture-to-defend-against-targeted-attacks>

    40 min presentation at OpenStack Summit Austin, April 2016,
    including IDS/IPS use cases and a demo with snort.

- `Tap-as-a-Service (TaaS): Port Monitoring for Neutron Networks
  <https://www.openstack.org/summit/vancouver-2015/summit-videos/presentation/tap-as-a-service-taas-port-monitoring-for-neutron-networks>`_

    40 min presentation at OpenStack Summit Vancouver, May 2015,
    including a demo.
