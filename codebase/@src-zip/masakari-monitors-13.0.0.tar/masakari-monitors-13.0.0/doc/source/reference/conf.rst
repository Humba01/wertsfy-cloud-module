.. _monitors-config:

---------------------------------------
Masakari Monitors Configuration Options
---------------------------------------

The following is an overview of all available configuration options in
masakari-monitors.
To see sample configuration file, see :ref:`monitors-config-file`.

.. show-options::
   :config-file: etc/masakarimonitors/masakarimonitors-config-generator.conf
