============
Installation
============

At the command line::

    $ pip install osc-placement

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv osc-placement
    $ pip install osc-placement
