=============
osc-placement
=============

.. We exclude the first few lines of the README since we don't need the badges
   (which don't render without extensions due to their SVG'ness) and we don't
   want two headers in this file

.. include:: ../../README.rst
   :start-line: 7

Contents
--------

.. toctree::
   :maxdepth: 2

   install/index
   contributor/index
   cli/index
   user/index

.. only:: html

   Indices and tables
   ==================

   * :ref:`genindex`
   * :ref:`search`
