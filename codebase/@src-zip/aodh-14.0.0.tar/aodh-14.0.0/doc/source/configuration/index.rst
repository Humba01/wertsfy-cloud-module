.. _configuring:

===================
Configuration Guide
===================

.. toctree::
    aodh-config-file.rst
    aodh-config-options.rst
    policy
    sample-policy-yaml
