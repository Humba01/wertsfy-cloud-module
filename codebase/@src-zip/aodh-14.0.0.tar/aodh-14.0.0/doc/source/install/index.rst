==================
Installation Guide
==================

.. toctree::

   get_started.rst
   install-obs.rst
   install-rdo.rst
   install-ubuntu.rst
   next-steps.rst
.. verify.rst

This chapter assumes a working setup of OpenStack following the
`OpenStack Installation Tutorials and Guides <https://docs.openstack.org/#install-guides>`_.
