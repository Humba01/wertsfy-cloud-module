============
Installation
============

At the command line::

    $ pip install python-brick-cinderclient-ext

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv python-brick-cinderclient-ext
    $ pip install python-brick-cinderclient-ext
