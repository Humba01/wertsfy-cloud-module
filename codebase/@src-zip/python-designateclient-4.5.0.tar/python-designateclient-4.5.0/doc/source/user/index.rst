==============================
 Using python-designateclient
==============================

.. toctree::

   bindings
   shell-v2
