import logging

logging.basicConfig(
    filename='functional-tests.log',
    filemode='w',
    level=logging.DEBUG,
)
