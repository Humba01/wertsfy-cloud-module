========
Usage
========

To use ceilometermiddleware in a project::

    import ceilometermiddleware
