=====================
Cyborg Tempest Plugin
=====================

This is a cyorg tempest plugin package. Tests can be run as a tempest plugin
against any cyborg-enabled OpenStack cloud.

Please fill here a long description which must be at least 3 lines wrapped on
80 cols, so that distribution package maintainers can use it in their packages.
Note that this is a hard requirement.

* Free software: Apache license
* Documentation: https://docs.openstack.org/cyborg-tempest-plugin/latest
* Source: https://opendev.org/openstack/cyborg-tempest-plugin/
* Bugs: https://storyboard.openstack.org/#!/project/968

Features
--------

* TODO
