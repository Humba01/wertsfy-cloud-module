#!/bin/sh
service apache2 start