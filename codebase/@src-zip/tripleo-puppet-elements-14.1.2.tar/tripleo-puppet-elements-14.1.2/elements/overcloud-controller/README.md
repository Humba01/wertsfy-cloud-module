Install all packages required for the overcloud controller role.
