Install all packages required for the overcloud compute role.
