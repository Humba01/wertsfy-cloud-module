============
Installation
============

Tempest automatically discovers installed plugins. That's why you just need
to install the Python packages that contains the Blazar Tempest plugin in
the same environment where Tempest is installed.

At the command line::

    $ git clone https://opendev.org/openstack/blazar-tempest-plugin
    $ cd blazar-tempest-plugin/
    $ pip install -e .
