====================
Administrators guide
====================

Administrators guide of openstack.
