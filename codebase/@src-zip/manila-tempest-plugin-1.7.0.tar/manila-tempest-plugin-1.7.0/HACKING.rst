OpenStack Style Commandments
============================

Read the OpenStack Style Commandments here:

    https://docs.openstack.org/hacking/latest/
