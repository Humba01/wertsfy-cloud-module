============================
 Murano Agent Release Notes
============================

.. toctree::
   :maxdepth: 2

   unreleased
   xena
   wallaby
   victoria
   ussuri
   train
   stein
   rocky
   queens
   pike
   ocata
   newton
   mitaka
   liberty
