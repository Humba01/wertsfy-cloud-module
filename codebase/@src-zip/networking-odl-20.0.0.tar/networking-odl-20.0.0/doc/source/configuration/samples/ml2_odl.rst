=======================
Sample ml2_conf_odl.ini
=======================

This is sample for ml2_conf_odl.ini.

.. literalinclude:: ../../../../etc/neutron/plugins/ml2/ml2_conf_odl.ini
