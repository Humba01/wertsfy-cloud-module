OpenStack Placement Documentation README
========================================

Configuration, contributor, install, and usage documentation
is sourced here and built to:
https://docs.openstack.org/placement/latest/

Note that the Placement API reference is maintained under
the ``/api-ref`` directory and built to:
https://docs.openstack.org/api-ref/placement/
