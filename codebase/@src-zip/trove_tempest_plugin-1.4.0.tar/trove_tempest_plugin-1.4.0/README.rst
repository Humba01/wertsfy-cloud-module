====================
Trove Tempest Plugin
====================

Tempest plugin for Trove Project

It contains tempest tests for Trove project.

* Free software: Apache license
* Documentation: https://docs.openstack.org/trove/latest/
* Source: https://git.openstack.org/cgit/openstack/trove-tempest-plugin
* Bugs: https://bugs.launchpad.net/trove
