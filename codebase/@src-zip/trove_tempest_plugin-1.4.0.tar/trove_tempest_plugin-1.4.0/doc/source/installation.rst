============
Installation
============

Tempest automatically discovers installed plugins. That's why you just need
to install the Python packages that contains the Trove Tempest plugin in
the same environment where Tempest is installed.

At the command line::

    $ git clone https://git.openstack.org/openstack/trove-tempest-plugin
    $ cd trove-tempest-plugin/
    $ pip install trove-tempest-plugin
