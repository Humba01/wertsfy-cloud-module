================================
Module - ovs_dpdk_pmd_cpus_check
================================


This module provides for the following ansible plugin:

    * ovs_dpdk_pmd_cpus_check


.. ansibleautoplugin::
   :module: library/ovs_dpdk_pmd_cpus_check.py
   :documentation: true
   :examples: true

