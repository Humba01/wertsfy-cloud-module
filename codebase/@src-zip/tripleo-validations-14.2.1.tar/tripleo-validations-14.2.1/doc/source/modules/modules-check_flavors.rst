======================
Module - check_flavors
======================


This module provides for the following ansible plugin:

    * check_flavors


.. ansibleautoplugin::
   :module: library/check_flavors.py
   :documentation: true
   :examples: true

