===================
Module - node_disks
===================


This module provides for the following ansible plugin:

    * node_disks


.. ansibleautoplugin::
   :module: library/node_disks.py
   :documentation: true
   :examples: true

