====================
Module - overcloudrc
====================


This module provides for the following ansible plugin:

    * overcloudrc


.. ansibleautoplugin::
   :module: library/overcloudrc.py
   :documentation: true
   :examples: true

