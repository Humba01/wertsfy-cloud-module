==========================================
Module - check_cpus_aligned_with_dpdk_nics
==========================================


This module provides for the following ansible plugin:

    * check_cpus_aligned_with_dpdk_nics


.. ansibleautoplugin::
   :module: library/check_cpus_aligned_with_dpdk_nics.py
   :documentation: true
   :examples: true

