=============================
Module - tripleo_haproxy_conf
=============================


This module provides for the following ansible plugin:

    * tripleo_haproxy_conf


.. ansibleautoplugin::
   :module: library/tripleo_haproxy_conf.py
   :documentation: true
   :examples: true
