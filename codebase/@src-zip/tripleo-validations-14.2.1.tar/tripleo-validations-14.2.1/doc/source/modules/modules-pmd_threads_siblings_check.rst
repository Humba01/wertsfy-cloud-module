===================================
Module - pmd_threads_siblings_check
===================================


This module provides for the following ansible plugin:

    * pmd_threads_siblings_check


.. ansibleautoplugin::
   :module: library/pmd_threads_siblings_check.py
   :documentation: true
   :examples: true

