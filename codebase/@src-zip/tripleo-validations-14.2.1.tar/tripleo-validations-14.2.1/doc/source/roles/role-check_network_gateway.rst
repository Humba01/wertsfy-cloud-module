=====================
check_network_gateway
=====================

.. ansibleautoplugin::
   :role: roles/check_network_gateway

