=========================
undercloud_service_status
=========================

.. ansibleautoplugin::
   :role: roles/undercloud_service_status

