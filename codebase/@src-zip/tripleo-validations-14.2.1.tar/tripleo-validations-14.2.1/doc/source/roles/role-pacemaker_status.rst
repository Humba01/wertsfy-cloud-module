================
pacemaker_status
================

.. ansibleautoplugin::
   :role: roles/pacemaker_status

