=========================
check_for_dangling_images
=========================

.. literalinclude:: ../../../roles/check_for_dangling_images/README.md

.. ansibleautoplugin::
  :role: roles/check_for_dangling_images
