===============
package_version
===============

.. ansibleautoplugin::
  :role: roles/package_version
