==========================
healthcheck_service_status
==========================

.. ansibleautoplugin::
   :role: roles/healthcheck_service_status
