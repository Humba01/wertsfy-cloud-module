===============
validation_init
===============

.. literalinclude:: ../../../roles/validation_init/README.md

.. ansibleautoplugin::
   :role: roles/validation_init
