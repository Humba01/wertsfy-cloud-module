================
controller_token
================

.. ansibleautoplugin::
   :role: roles/controller_token

