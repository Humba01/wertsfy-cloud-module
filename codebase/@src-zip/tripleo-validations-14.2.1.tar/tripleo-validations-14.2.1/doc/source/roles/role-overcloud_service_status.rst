========================
overcloud_service_status
========================

.. ansibleautoplugin::
   :role: roles/overcloud_service_status

