==================
check_rhsm_version
==================

.. ansibleautoplugin::
  :role: roles/check_rhsm_version
