===================
nova_event_callback
===================

.. ansibleautoplugin::
   :role: roles/nova_event_callback

