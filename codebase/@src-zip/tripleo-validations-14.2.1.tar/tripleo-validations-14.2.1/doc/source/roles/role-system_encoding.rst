===============
system_encoding
===============

.. ansibleautoplugin::
  :role: roles/system_encoding
