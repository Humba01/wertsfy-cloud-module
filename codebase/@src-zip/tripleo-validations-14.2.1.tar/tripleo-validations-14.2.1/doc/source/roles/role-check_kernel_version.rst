====================
check_kernel_version
====================

.. ansibleautoplugin::
  :role: roles/check_kernel_version
