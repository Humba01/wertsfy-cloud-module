===============
rabbitmq_limits
===============

.. ansibleautoplugin::
   :role: roles/rabbitmq_limits

