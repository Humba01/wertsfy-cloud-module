========================
undercloud_process_count
========================

.. ansibleautoplugin::
   :role: roles/undercloud_process_count

