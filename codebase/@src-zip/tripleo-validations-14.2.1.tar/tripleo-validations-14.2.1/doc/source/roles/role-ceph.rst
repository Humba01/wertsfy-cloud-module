====
ceph
====

.. ansibleautoplugin::
   :role: roles/ceph

