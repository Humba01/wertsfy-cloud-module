==============
tls_everywhere
==============

.. ansibleautoplugin::
   :role: roles/tls_everywhere

