===========
node_health
===========

.. ansibleautoplugin::
   :role: roles/node_health

