================
container_status
================

.. ansibleautoplugin::
   :role: roles/container_status
