======================
openshift_on_openstack
======================

.. ansibleautoplugin::
   :role: roles/openshift_on_openstack

