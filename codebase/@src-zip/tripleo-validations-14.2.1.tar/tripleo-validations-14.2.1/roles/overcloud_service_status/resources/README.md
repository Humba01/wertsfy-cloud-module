Shared resources used for molecule unit testing
