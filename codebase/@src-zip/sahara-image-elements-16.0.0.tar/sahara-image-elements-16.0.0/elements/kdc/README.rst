===
kdc
===

Installs all needed artifacts for KDC server and Kerberos authentication

Environment Variables
---------------------

DIB_UNLIMITED_SECURITY_LOCATION
  :Required: No
  :Default: https://tarballs.openstack.org/sahara-extra/dist/common-artifacts/
  :Description: Place where UnlimitedSecurity polices are located
