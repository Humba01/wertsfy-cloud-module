===
ssh
===

This element installs an SSH server then configures it to be suitable
for use with Sahara.
