====
java
====

This element configures JAVA_HOME, PATH and the alternatives
for java and javac.
