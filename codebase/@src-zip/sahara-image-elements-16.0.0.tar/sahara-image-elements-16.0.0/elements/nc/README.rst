==
nc
==

This element installs nc/netcat.
