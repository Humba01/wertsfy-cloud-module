=========
s3_hadoop
=========

Copy the Hadoop S3 connector libraries into the Hadoop and Spark classpaths.

Environment Variables
---------------------

None.
