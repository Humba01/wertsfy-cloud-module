=============
centos-mirror
=============

This element sets up the mirror for updating the CentOS cloud image.
Using a mirror improves the speed of the image building.

Environment Variables
---------------------

CENTOS_MIRROR
  :Required: Yes
  :Description: URL to the CentOS mirror.
