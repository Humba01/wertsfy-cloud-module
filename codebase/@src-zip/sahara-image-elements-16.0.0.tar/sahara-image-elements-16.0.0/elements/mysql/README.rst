=====
mysql
=====

This element sets up the basic components of MySQL.

It is light version of original MySQL element
(https://github.com/openstack/tripleo-image-elements/tree/master/elements/mysql).
