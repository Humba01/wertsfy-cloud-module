=============
Rally plugins
=============


All *.py modules from this directory will auto loaded by Rally and all
plugins will be discoverable. There is no need in any extra configuration
and there is no difference between writing them here and in rally code base.

Note that it is better to push to Rally code base all interested and useful
benchmarks, cause that simplifies a lot life of operators.

