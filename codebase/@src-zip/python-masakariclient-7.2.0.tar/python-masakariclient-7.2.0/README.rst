=====================
python-masakariclient
=====================

masakariclient module and a CLI tool for masakari

Please fill here a long description which must be at least 3 lines wrapped on
80 cols, so that distribution package maintainers can use it in their packages.
Note that this is a hard requirement.

* Free software: Apache license
* Documentation: https://docs.openstack.org/python-masakariclient/latest/
* Source: https://opendev.org/openstack/python-masakariclient
* Bugs: https://bugs.launchpad.net/python-masakariclient
* Release Notes: https://docs.openstack.org/releasenotes/python-masakariclient

Features
--------

* TODO
