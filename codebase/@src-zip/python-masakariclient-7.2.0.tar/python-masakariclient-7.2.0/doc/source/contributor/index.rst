=================
Contributor Guide
=================

In the Contributor Guide, you will find information on tackerclient's
lower level programming details or APIs as well as the transition to
OpenStack client.

.. toctree::
   :maxdepth: 2

   contributing.rst
   developing.rst
