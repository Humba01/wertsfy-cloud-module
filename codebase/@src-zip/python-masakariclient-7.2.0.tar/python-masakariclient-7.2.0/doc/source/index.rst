.. python-masakariclient documentation master file, created by
   sphinx-quickstart on Tue Jul  9 22:26:36 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

=================================================
Welcome to python-masakariclient's documentation!
=================================================

Masakariclient is a command-line client for Masakari.

Contents
========

.. toctree::
   :maxdepth: 2

   install/index
   cli/index
   contributor/index

Release Notes
=============

.. toctree::
   :maxdepth: 1

   Release Notes <https://docs.openstack.org/releasenotes/python-masakariclient/>

For Contributors
================

* If you are a new contributor to Python-masakariclient please refer: :doc:`contributor/contributing`

  .. toctree::
     :hidden:

     contributor/contributing

Indices and Tables
==================

* :ref:`genindex`
* :ref:`search`
