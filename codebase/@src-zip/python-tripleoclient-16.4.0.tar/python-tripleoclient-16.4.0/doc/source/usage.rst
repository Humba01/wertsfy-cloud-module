=====
Usage
=====

To use tripleoclient in a project::

	import tripleoclient
