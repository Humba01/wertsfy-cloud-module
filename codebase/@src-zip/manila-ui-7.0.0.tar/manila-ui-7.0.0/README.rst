Team and repository tags
------------------------

.. image:: https://governance.openstack.org/tc/badges/manila-ui.svg
    :target: https://governance.openstack.org/tc/reference/tags/index.html

.. Change things from this point on

=======================================
manila-ui - Manila Management Dashboard
=======================================

* Free software: Apache license
* Documentation: https://docs.openstack.org/manila-ui/latest/
* Release notes: https://docs.openstack.org/releasenotes/manila-ui/
* Source: https://opendev.org/openstack/manila-ui
* Bugs: https://bugs.launchpad.net/manila-ui
