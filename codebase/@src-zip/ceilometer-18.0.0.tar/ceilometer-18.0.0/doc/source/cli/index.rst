============================
Ceilometer CLI Documentation
============================

In this section you will find information on Ceilometer’s command line
interface.

.. toctree::
   :maxdepth: 1

   ceilometer-status
